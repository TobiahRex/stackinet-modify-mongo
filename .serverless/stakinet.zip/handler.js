(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	var _extends2 = __webpack_require__(1);

	var _extends3 = _interopRequireDefault(_extends2);

	var _stringify = __webpack_require__(2);

	var _stringify2 = _interopRequireDefault(_stringify);

	var _bluebird = __webpack_require__(3);

	var _handleModification = __webpack_require__(4);

	var _handleModification2 = _interopRequireDefault(_handleModification);

	var _connection = __webpack_require__(7);

	var _connection2 = _interopRequireDefault(_connection);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	if (!global._babelPolyfill) __webpack_require__(26);

	module.exports.modifyMongo = function (event, context) {
	  console.log('\nEVENT: ', (0, _stringify2.default)(event, null, 2));

	  if (!event.body.databaseName || !event.body.collectionName || !event.body.operationName) {
	    return context.fail({ message: 'Missing required arguments.' }) && context.done();
	  }

	  return (0, _connection2.default)(event.body.databaseName).then(function (dbResults) {
	    return (0, _handleModification2.default)((0, _extends3.default)({ event: event }, dbResults));
	  }).then(function (result) {
	    return context.succeed(result) && context.done();
	  }).catch(function (error) {
	    console.log('\nFINAL ERROR: \n', (0, _stringify2.default)(error, null, 2));
	    return context.fail('Mongo cluster modification failed. ERROR: ' + error) && context.done();
	  });
	};

/***/ }),
/* 1 */
/***/ (function(module, exports) {

	module.exports = require("babel-runtime/helpers/extends");

/***/ }),
/* 2 */
/***/ (function(module, exports) {

	module.exports = require("babel-runtime/core-js/json/stringify");

/***/ }),
/* 3 */
/***/ (function(module, exports) {

	module.exports = require("bluebird");

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _keys = __webpack_require__(5);

	var _keys2 = _interopRequireDefault(_keys);

	var _promise = __webpack_require__(6);

	var _promise2 = _interopRequireDefault(_promise);

	var _bluebird = __webpack_require__(3);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	/**
	* 1) Dynamically create, update, or delete Documents on Mongo Collections.
	*
	* @param {object} event - Lambda event object.
	* - Keys: operationName, collectionName, {other Args for operation.}
	* @param {object} <Collections> - Mongo Collections containing documents to be mutated or created.
	*
	* @return {object} modified Document - Promises: resolved.
	*/

	exports.default = function (_ref) {
	  var event = _ref.event,
	      dbModels = _ref.dbModels;
	  return new _promise2.default(function (resolve, reject) {
	    console.log('\nSTART: Handling modification... ', '\noperationName: ', event.body.operationName, '\ncollectionName: ', event.body.collectionName, '\n\ndbModels: ', (0, _keys2.default)(dbModels));

	    var _event$body = event.body,
	        operationName = _event$body.operationName,
	        collectionName = _event$body.collectionName;

	    console.log('event: ', event);

	    switch (operationName) {
	      case 'dropCollection':
	        {
	          return dbModels[collectionName].dropCollection().then(resolve).catch(reject);
	        }

	      case 'removeOne':
	        {
	          return dbModels[collectionName].removeOne(event.body).then(resolve).catch(reject);
	        }

	      case 'updateDoc':
	        {
	          return dbModels[collectionName].updateDoc(event.body).then(resolve).catch(reject);
	        }

	      case 'createDoc':
	        {
	          return dbModels[collectionName].createDoc(event.body).then(resolve).catch(reject);
	        }

	      default:
	        {
	          console.log('\n\nNo operation executed.  Verify input arguments.');
	          reject('No operation executed.  Verify input arguments.');
	        }
	    }
	    reject('operationName: ' + operationName + ' does not exist.');
	  });
	};

/***/ }),
/* 5 */
/***/ (function(module, exports) {

	module.exports = require("babel-runtime/core-js/object/keys");

/***/ }),
/* 6 */
/***/ (function(module, exports) {

	module.exports = require("babel-runtime/core-js/promise");

/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _extends2 = __webpack_require__(1);

	var _extends3 = _interopRequireDefault(_extends2);

	var _promise = __webpack_require__(6);

	var _promise2 = _interopRequireDefault(_promise);

	var _mongoose = __webpack_require__(8);

	var _mongoose2 = _interopRequireDefault(_mongoose);

	var _email = __webpack_require__(9);

	var _email2 = _interopRequireDefault(_email);

	var _marketHero = __webpack_require__(15);

	var _marketHero2 = _interopRequireDefault(_marketHero);

	var _product = __webpack_require__(17);

	var _product2 = _interopRequireDefault(_product);

	var _sagawa = __webpack_require__(19);

	var _sagawa2 = _interopRequireDefault(_sagawa);

	var _transaction = __webpack_require__(21);

	var _transaction2 = _interopRequireDefault(_transaction);

	var _user = __webpack_require__(23);

	var _user2 = _interopRequireDefault(_user);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	_mongoose2.default.Promise = _promise2.default; /* eslint-disable no-console, no-constant-condition, no-unused-vars */

	var dotenv = __webpack_require__(25).config({ silent: true }); //eslint-disable-line
	var lonesmokeMongo = process.env.LONESMOKE_MONGO_URI;
	var nj2jpMongo = process.env.NJ2JP_MONGO_URI;

	if (!lonesmokeMongo || !nj2jpMongo) {
	  console.log('Lonesmoke MONGO value is: ' + (lonesmokeMongo || 'undefined'));
	  console.log('Nj2jp MONGO value is: ' + (lonesmokeMongo || 'undefined'));
	}

	var cachedDb = {
	  lonesmoke: {
	    connection: null,
	    dbModels: {
	      Email: null,
	      Complaint: null,
	      MarketHero: null
	    }
	  },
	  nj2jp: {
	    connection: null,
	    dbModels: {
	      User: null,
	      Email: null,
	      Transactions: null
	    }
	  }
	};

	var verifyDb = function verifyDb(dbName) {
	  return new _promise2.default(function (resolve, reject) {
	    switch (dbName.toLowerCase()) {
	      case 'lonesmoke':
	        {
	          console.log('cachedDb.lonesmoke.connection', cachedDb.lonesmoke.connection);

	          if (cachedDb.lonesmoke.connection && cachedDb.lonesmoke.connection._readyState === 1) {
	            console.log('\nFOUND PREVIOUS LONESMOKE CONNECTION\n', '\nCurrent Connections: ', cachedDb.lonesmoke.connection.base.connections, 'cachedDb.lonesmokeConnection._readyState: ', cachedDb.lonesmoke.connection._readyState);

	            resolve(cachedDb.lonesmoke);
	          } else {
	            var connection = _mongoose2.default.createConnection(lonesmokeMongo, { replset: { poolSize: 100 } });
	            console.log('CREATED NEW ' + dbName + ' CONNECTION: ', connection);

	            cachedDb = (0, _extends3.default)({}, cachedDb, {
	              lonesmoke: {
	                connection: connection,
	                dbModels: {
	                  Email: (0, _email2.default)(connection),
	                  MarketHero: (0, _marketHero2.default)(connection)
	                }
	              }
	            });

	            resolve(cachedDb.lonesmoke);
	          }
	        }break;
	      case 'nj2jp':
	        {
	          if (cachedDb.nj2jp.connection && cachedDb.nj2jp.connection._readyState === 1) {
	            console.log('cachedDb.nj2jpConnection._readyState: ', cachedDb.nj2jp.connection._readyState, '\nFound previous Nj2jp CONNECTION\n', '\nCurrent NJ2JP Connections: ', cachedDb.nj2jp.connection.base.connections);
	            resolve(cachedDb.nj2jp);
	          } else {
	            var _connection = _mongoose2.default.createConnection(nj2jpMongo, { replset: { poolSize: 100 } });
	            console.log('CREATED NEW ' + dbName + ' CONNECTION: ', _connection);

	            cachedDb = (0, _extends3.default)({}, cachedDb, {
	              nj2jp: {
	                connection: _connection,
	                dbModels: {
	                  Email: (0, _email2.default)(_connection),
	                  MarketHero: (0, _marketHero2.default)(_connection),
	                  Product: (0, _product2.default)(_connection),
	                  Sagawa: (0, _sagawa2.default)(_connection),
	                  Transaction: (0, _transaction2.default)(_connection),
	                  User: (0, _user2.default)(_connection)
	                }
	              }
	            });

	            resolve(cachedDb.nj2jp);
	          }
	        }break;
	      default:
	        {
	          console.log('\nError that dbName did not match any databases in the Stakinet cluster.');
	          reject('Error that dbName did not match any databases in the Stakinet cluster.');
	        }break;
	    }
	  });
	};

	exports.default = verifyDb;

/***/ }),
/* 8 */
/***/ (function(module, exports) {

	module.exports = require("mongoose");

/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _keys = __webpack_require__(5);

	var _keys2 = _interopRequireDefault(_keys);

	var _assign = __webpack_require__(10);

	var _assign2 = _interopRequireDefault(_assign);

	var _extends2 = __webpack_require__(1);

	var _extends3 = _interopRequireDefault(_extends2);

	var _promise = __webpack_require__(6);

	var _promise2 = _interopRequireDefault(_promise);

	var _awsSdk = __webpack_require__(11);

	var _awsSdk2 = _interopRequireDefault(_awsSdk);

	var _bluebird = __webpack_require__(3);

	var _isEmail = __webpack_require__(12);

	var _isEmail2 = _interopRequireDefault(_isEmail);

	var _email = __webpack_require__(13);

	var _email2 = _interopRequireDefault(_email);

	var _config = __webpack_require__(14);

	var _config2 = _interopRequireDefault(_config);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	_awsSdk2.default.config.update({
	  accessKeyId: _config2.default.aws.accessKeyId,
	  secretAccessKey: _config2.default.aws.secretAccessKey,
	  region: _config2.default.aws.sesEmailRegion
	}); /* eslint-disable no-use-before-define, no-console, import/newline-after-import */


	var ses = new _awsSdk2.default.SES();

	exports.default = function (db) {
	  /**
	  * 1) Remove all documents instances.
	  *
	  * @param {string} collectionName - name of collection - only used to Verify operation accuracy with console.logs.
	  *
	  * @return {object} - Promise: resolved - Email details.
	  */
	  _email2.default.statics.dropCollection = function (collectionName) {
	    return new _promise2.default(function (resolve, reject) {
	      console.log('\n\n@Email.dropCollection');

	      return _bluebird.Promise.fromCallback(function (cb) {
	        return Email.remove({}, cb);
	      }).then(function (result) {
	        console.log('\nSuccessfully removed all Documents on the ', collectionName, ' collection.\nResult: ', result);
	        resolve(result);
	      }).catch(function (error) {
	        console.log('\nERROR trying to drop collection ', collectionName);
	        reject(error);
	      });
	    });
	  };
	  /**
	  * 1) Validate required fields exist.
	  * 2) Create a new email.
	  *
	  * @param {object} fields - Required fields for creating new Email.
	  *
	  * @return {object} - Promise: resolved - Email details.
	  */
	  _email2.default.statics.createDoc = function (fields) {
	    return new _promise2.default(function (resolve, reject) {
	      console.log('\n\n@Email.createEmail');

	      if (!fields) return reject('Missing required arguments. "fields": ' + (fields || 'undefined'));

	      var type = fields.type,
	          purpose = fields.purpose,
	          language = fields.language,
	          subjectData = fields.subjectData,
	          bodyHtmlData = fields.bodyHtmlData,
	          bodyTextData = fields.bodyTextData,
	          replyToAddress = fields.replyToAddress;


	      if (!type || !purpose || !language || !replyToAddress || !subjectData || !bodyHtmlData || !bodyTextData) {
	        reject((0, _extends3.default)({ error: 'Missing required fields to create a new Email.' }, fields));
	      } else {
	        _bluebird.Promise.fromCallback(function (cb) {
	          return Email.create((0, _extends3.default)({}, fields), cb);
	        }).then(function (newEmail) {
	          console.log('\nSuccessfully created new Email!\n _id: ', newEmail._id);
	          resolve(newEmail);
	        });
	      }
	    });
	  };

	  _email2.default.statics.removeOne = function (_ref) {
	    var id = _ref.id;
	    return new _promise2.default(function (resolve, reject) {
	      console.log('\n\n@Email.removeOne');

	      if (!id) return reject('Missing required arguments. "id": ' + (id || 'undefined'));

	      Email.findByIdAndRemove(id).exec().then(function (deletedDoc) {
	        console.log('\nSuccessfully removed _id: ', deletedDoc._id);
	        resolve(deletedDoc);
	      }).catch(function (error) {
	        console.log('Error trying to remove document with _id "' + id + '"');
	        reject('Error trying to remove document with _id "' + id + '"');
	      });
	    });
	  };

	  _email2.default.statics.updateDoc = function (eventBody) {
	    return new _promise2.default(function (resolve, reject) {
	      console.log('\n\n@Email.updateDoc');

	      if (!eventBody) return reject('Missing required arguments. "eventBody": ' + (eventBody || 'undefined'));

	      delete eventBody.collectionName;
	      delete eventBody.databaseName;
	      delete eventBody.operationName;

	      var updateArgs = (0, _assign2.default)({}, eventBody);
	      (0, _keys2.default)(updateArgs).forEach(function (key) {
	        if (/\[\]/gi.test(updateArgs[key])) {
	          try {
	            updateArgs[key] = JSON.parse(updateArgs[key]);
	          } catch (error) {
	            reject('ERROR while trying to parse input string array into array literal.  ERROR = ' + error + '.');
	            return null;
	          }
	        }
	      });

	      Email.findByIdAndUpdate({ _id: eventBody.id }, { $set: updateArgs }, { new: true }).exec().then(function (result) {
	        console.log('Successfully updated collection ' + eventBody.collectionName + '.  RESULT = ' + result);
	        return resolve(result);
	      }).catch(function (error) {
	        console.log('Error trying to update collection "' + eventBody.collectionName + '".  ERROR = ' + error);
	        return reject(error);
	      });
	    });
	  };

	  console.log('\n\nCreating Email collection...');
	  var Email = db.model('Email', _email2.default);
	  return Email;
	};

/***/ }),
/* 10 */
/***/ (function(module, exports) {

	module.exports = require("babel-runtime/core-js/object/assign");

/***/ }),
/* 11 */
/***/ (function(module, exports) {

	module.exports = require("aws-sdk");

/***/ }),
/* 12 */
/***/ (function(module, exports) {

	module.exports = require("validator/lib/isEmail");

/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	var Schema = __webpack_require__(8).Schema;

	var ObjectId = exports.ObjectId = Schema.Types.ObjectId;

	var emailSchema = new Schema({
	  type: { type: String, required: true },
	  created: { type: Date, default: Date.now },
	  purpose: { type: String, required: true },
	  language: { type: String, required: true },
	  replyToAddress: { type: String, required: true },
	  subjectData: { type: String, required: true },
	  subjectCharset: { type: String, default: 'utf8' },
	  bodyHtmlData: { type: String, required: true },
	  bodyHtmlCharset: { type: String, default: 'utf8' },
	  bodyTextData: { type: String, requried: true },
	  bodyTextCharset: { type: String, default: 'utf8' },
	  sentEmails: [{
	    messageId: { type: String },
	    sesStatus: { type: String }
	  }]
	}, { bufferCommands: true });
	exports.default = emailSchema;

/***/ }),
/* 14 */
/***/ (function(module, exports) {

	module.exports = {
		"aws": {
			"accessKeyId": "AKIAJ74ZCSVFKDKPSAXA",
			"secretAccessKey": "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",
			"region": "ap-northeast-1",
			"sesEmailRegion": "us-east-1"
		}
	};

/***/ }),
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _keys = __webpack_require__(5);

	var _keys2 = _interopRequireDefault(_keys);

	var _assign = __webpack_require__(10);

	var _assign2 = _interopRequireDefault(_assign);

	var _promise = __webpack_require__(6);

	var _promise2 = _interopRequireDefault(_promise);

	var _bluebird = __webpack_require__(3);

	var _MarketHero = __webpack_require__(16);

	var _MarketHero2 = _interopRequireDefault(_MarketHero);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	/* eslint-disable no-use-before-define, no-console, import/newline-after-import */
	exports.default = function (db) {
	  /**
	  * 1) Remove all documents instances.
	  *
	  * @param {string} collectionName - name of collection - only used to Verify operation accuracy with console.logs.
	  *
	  * @return {object} - Promise: resolved - MarketHero details.
	  */
	  _MarketHero2.default.statics.dropCollection = function (collectionName) {
	    return new _promise2.default(function (resolve, reject) {
	      console.log('\n\n@MarketHero.dropCollection');

	      return _bluebird.Promise.fromCallback(function (cb) {
	        return MarketHero.remove({}, cb);
	      }).then(function (result) {
	        console.log('\nSuccessfully removed all Documents on the ', collectionName, ' collection.\nResult: ', result);
	        resolve(result);
	      }).catch(function (error) {
	        console.log('\nERROR trying to drop collection ', collectionName);
	        reject(error);
	      });
	    });
	  };

	  _MarketHero2.default.statics.removeOne = function (_ref) {
	    var id = _ref.id;
	    return new _promise2.default(function (resolve, reject) {
	      console.log('\n\n@MarketHero.removeOne');

	      if (!id) return reject('Missing required arguments. "id": ' + (id || 'undefined'));

	      MarketHero.findByIdAndRemove(id).exec().then(function (deletedDoc) {
	        console.log('\nSuccessfully removed _id: ', deletedDoc._id);
	        resolve(deletedDoc);
	      }).catch(function (error) {
	        console.log('Error trying to remove document with _id "' + id + '"');
	        reject('Error trying to remove document with _id "' + id + '"');
	      });
	    });
	  };

	  _MarketHero2.default.statics.updateDoc = function (eventBody) {
	    return new _promise2.default(function (resolve, reject) {
	      console.log('\n\n@MarketHero.updateDoc');

	      if (!eventBody) return reject('Missing required arguments. "eventBody": ' + (eventBody || 'undefined'));

	      delete eventBody.collectionName;
	      delete eventBody.databaseName;
	      delete eventBody.operationName;

	      var updateArgs = (0, _assign2.default)({}, eventBody);
	      (0, _keys2.default)(updateArgs).forEach(function (key) {
	        if (/\[\]/gi.test(updateArgs[key])) {
	          try {
	            updateArgs[key] = JSON.parse(updateArgs[key]);
	          } catch (error) {
	            reject('ERROR while trying to parse input string array into array literal.  ERROR = ' + error + '.');
	            return null;
	          }
	        }
	      });

	      MarketHero.findByIdAndUpdate({ _id: eventBody.id }, { $set: updateArgs }, { new: true }).exec().then(function (result) {
	        console.log('Successfully updated collection ' + eventBody.collectionName + '.  RESULT = ' + result);
	        return resolve(result);
	      }).catch(function (error) {
	        console.log('Error trying to update collection "' + eventBody.collectionName + '".  ERROR = ' + error);
	        return reject(error);
	      });
	    });
	  };

	  console.log('\n\nCreating MarketHero collection...');
	  var MarketHero = db.model('MarketHero', _MarketHero2.default);
	  return MarketHero;
	};

/***/ }),
/* 16 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	var Schema = __webpack_require__(8).Schema;

	var ObjectId = exports.ObjectId = Schema.Types.ObjectId;
	var marketHeroSchema = new Schema({
	  lead: {
	    email: { type: String, required: true },
	    date: { type: Date, default: Date.now },
	    firstName: { type: String, default: 'John' },
	    lastName: { type: String, default: 'Doe' }
	  },
	  tags: [{
	    name: { type: String },
	    description: { type: String },
	    date: { type: Date }
	  }]
	}, { bufferCommands: true });
	exports.default = marketHeroSchema;
	/* Schema Breakdown.
	  "leads": Leads is an array of all the leads in the LoneSmoke database.

	  "tags": Tags is the an array of all the existing tags currently in existence.
	  - name: The name of the tag. e.g. "!beachDiscount"
	  - description: The details behind why the tag exists and it's purpose. e.g. "This customer signed up to receive a 10% discount from Zushi Beach".
	  - date: The date that this tag was created.
	*/

/***/ }),
/* 17 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _keys = __webpack_require__(5);

	var _keys2 = _interopRequireDefault(_keys);

	var _assign = __webpack_require__(10);

	var _assign2 = _interopRequireDefault(_assign);

	var _promise = __webpack_require__(6);

	var _promise2 = _interopRequireDefault(_promise);

	var _bluebird = __webpack_require__(3);

	var _Product = __webpack_require__(18);

	var _Product2 = _interopRequireDefault(_Product);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	/* eslint-disable no-use-before-define, no-console, import/newline-after-import */
	exports.default = function (db) {
	  /**
	  * 1) Remove all documents instances.
	  *
	  * @param {string} collectionName - name of collection - only used to Verify operation accuracy with console.logs.
	  *
	  * @return {object} - Promise: resolved - Product details.
	  */
	  _Product2.default.statics.dropCollection = function (collectionName) {
	    return new _promise2.default(function (resolve, reject) {
	      console.log('\n\n@Product.dropCollection');

	      return _bluebird.Promise.fromCallback(function (cb) {
	        return Product.remove({}, cb);
	      }).then(function (result) {
	        console.log('\nSuccessfully removed all Documents on the ', collectionName, ' collection.\nResult: ', result);
	        resolve(result);
	      }).catch(function (error) {
	        console.log('\nERROR trying to drop collection ', collectionName);
	        reject(error);
	      });
	    });
	  };

	  _Product2.default.statics.removeOne = function (_ref) {
	    var id = _ref.id;
	    return new _promise2.default(function (resolve, reject) {
	      console.log('\n\n@Product.removeOne');

	      if (!id) return reject('Missing required arguments. "id": ' + (id || 'undefined'));

	      Product.findByIdAndRemove(id).exec().then(function (deletedDoc) {
	        console.log('\nSuccessfully removed _id: ', deletedDoc._id);
	        resolve(deletedDoc);
	      }).catch(function (error) {
	        console.log('Error trying to remove document with _id "' + id + '"');
	        reject('Error trying to remove document with _id "' + id + '"');
	      });
	    });
	  };

	  _Product2.default.statics.updateDoc = function (eventBody) {
	    return new _promise2.default(function (resolve, reject) {
	      console.log('\n\n@Product.updateDoc');

	      if (!eventBody) return reject('Missing required arguments. "eventBody": ' + (eventBody || 'undefined'));

	      delete eventBody.collectionName;
	      delete eventBody.databaseName;
	      delete eventBody.operationName;

	      var updateArgs = (0, _assign2.default)({}, eventBody);
	      (0, _keys2.default)(updateArgs).forEach(function (key) {
	        if (/\[\]/gi.test(updateArgs[key])) {
	          try {
	            updateArgs[key] = JSON.parse(updateArgs[key]);
	          } catch (error) {
	            reject('ERROR while trying to parse input string array into array literal.  ERROR = ' + error + '.');
	            return null;
	          }
	        }
	      });

	      Product.findByIdAndUpdate({ _id: eventBody.id }, { $set: updateArgs }, { new: true }).exec().then(function (result) {
	        console.log('Successfully updated collection ' + eventBody.collectionName + '.  RESULT = ' + result);
	        return resolve(result);
	      }).catch(function (error) {
	        console.log('Error trying to update collection "' + eventBody.collectionName + '".  ERROR = ' + error);
	        return reject(error);
	      });
	    });
	  };

	  console.log('\n\nCreating Product collection...');
	  var Product = db.model('Product', _Product2.default);
	  return Product;
	};

/***/ }),
/* 18 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	var Schema = __webpack_require__(8).Schema;

	var ObjectId = exports.ObjectId = Schema.Types.ObjectId;
	var productSchema = new Schema({
	  product: {
	    mainTitle: {
	      type: String,
	      required: true
	    },
	    title: {
	      type: String,
	      required: true
	    },
	    flavor: {
	      type: String,
	      required: true
	    },
	    price: {
	      type: String,
	      required: true,
	      default: 30
	    },
	    sku: {
	      type: String,
	      required: true
	    },
	    size: {
	      type: Number,
	      enum: [30, 60, 120],
	      required: true
	    },
	    nicotineStrength: {
	      type: Number,
	      enum: [2, 4, 6, 8, 10, 12, 14, 16, 18],
	      required: true
	    },
	    images: [{
	      purpose: {
	        type: String,
	        required: true
	      },
	      url: {
	        type: String,
	        required: true
	      }
	    }],
	    routeTag: {
	      type: String,
	      required: true
	    },
	    vendor: { type: String },
	    blurb: {
	      type: String,
	      required: true
	    },
	    dates: {
	      added_to_store: {
	        type: Date,
	        default: Date.now
	      },
	      removed_from_store: {
	        type: Date
	      }
	    },
	    quantities: {
	      available: { type: Number },
	      in_cart: { type: Number }
	    }
	  },
	  reviews: [{
	    review_id: { type: ObjectId, ref: 'Reviews' },
	    user_id: { type: ObjectId, ref: 'User' }
	  }],
	  distribution: {
	    restock_threshold: {
	      type: Number,
	      default: 500
	    },
	    restock_amount: {
	      type: Number,
	      default: 500
	    },
	    last_replenishment: [{
	      date: {
	        type: Date
	      },
	      amount: {
	        type: Number,
	        default: 500
	      }
	    }],
	    wholesale_price: { type: Number }
	  },
	  statistics: {
	    adds_to_cart: { type: Number },
	    completed_checkouts: { type: Number },
	    transactions: [{
	      transaction_id: { type: ObjectId, ref: 'Transaction' },
	      user_id: { type: ObjectId, ref: 'User' }
	    }]
	  }
	}, { bufferCommands: true });
	exports.default = productSchema;

/***/ }),
/* 19 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _keys = __webpack_require__(5);

	var _keys2 = _interopRequireDefault(_keys);

	var _assign = __webpack_require__(10);

	var _assign2 = _interopRequireDefault(_assign);

	var _promise = __webpack_require__(6);

	var _promise2 = _interopRequireDefault(_promise);

	var _bluebird = __webpack_require__(3);

	var _Sagawa = __webpack_require__(20);

	var _Sagawa2 = _interopRequireDefault(_Sagawa);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	/* eslint-disable no-use-before-define, no-console, import/newline-after-import */
	exports.default = function (db) {
	  /**
	  * 1) Remove all documents instances.
	  *
	  * @param {string} collectionName - name of collection - only used to Verify operation accuracy with console.logs.
	  *
	  * @return {object} - Promise: resolved - Sagawa details.
	  */
	  _Sagawa2.default.statics.dropCollection = function (collectionName) {
	    return new _promise2.default(function (resolve, reject) {
	      console.log('\n\n@Sagawa.dropCollection');

	      return _bluebird.Promise.fromCallback(function (cb) {
	        return Sagawa.remove({}, cb);
	      }).then(function (result) {
	        console.log('\nSuccessfully removed all Documents on the ', collectionName, ' collection.\nResult: ', result);
	        resolve(result);
	      }).catch(function (error) {
	        console.log('\nERROR trying to drop collection ', collectionName);
	        reject(error);
	      });
	    });
	  };

	  _Sagawa2.default.statics.removeOne = function (_ref) {
	    var id = _ref.id;
	    return new _promise2.default(function (resolve, reject) {
	      console.log('\n\n@Sagawa.removeOne');

	      if (!id) return reject('Missing required arguments. "id": ' + (id || 'undefined'));

	      Sagawa.findByIdAndRemove(id).exec().then(function (deletedDoc) {
	        console.log('\nSuccessfully removed _id: ', deletedDoc._id);
	        resolve(deletedDoc);
	      }).catch(function (error) {
	        console.log('Error trying to remove document with _id "' + id + '"');
	        reject('Error trying to remove document with _id "' + id + '"');
	      });
	    });
	  };

	  _Sagawa2.default.statics.updateDoc = function (eventBody) {
	    return new _promise2.default(function (resolve, reject) {
	      console.log('\n\n@Sagawa.updateDoc');

	      if (!eventBody) return reject('Missing required arguments. "eventBody": ' + (eventBody || 'undefined'));

	      delete eventBody.collectionName;
	      delete eventBody.databaseName;
	      delete eventBody.operationName;

	      var updateArgs = (0, _assign2.default)({}, eventBody);

	      (0, _keys2.default)(updateArgs).forEach(function (key) {
	        if (/\[\]/gi.test(updateArgs[key])) {
	          try {
	            updateArgs[key] = JSON.parse(updateArgs[key]);
	          } catch (error) {
	            reject('ERROR while trying to parse input string array into array literal.  ERROR = ' + error + '.');
	            return null;
	          }
	        }
	      });

	      Sagawa.findByIdAndUpdate(eventBody.id, { $set: updateArgs }, { new: true }).exec().then(function (result) {
	        console.log('Successfully updated collection ' + eventBody.collectionName + '.  RESULT = ' + result);
	        return resolve(result);
	      }).catch(function (error) {
	        console.log('Error trying to update collection "' + eventBody.collectionName + '".  ERROR = ' + error);
	        return reject(error);
	      });
	    });
	  };

	  var Sagawa = db.model('Sagawa', _Sagawa2.default);
	  return Sagawa;
	};

/***/ }),
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	var Schema = __webpack_require__(8).Schema;

	var ObjectId = exports.ObjectId = Schema.Types.ObjectId;
	var sagawaSchema = new Schema({
	  error: {
	    hard: {
	      type: Boolean,
	      default: false
	    },
	    soft: {
	      type: Boolean,
	      default: false
	    },
	    message: {
	      type: String,
	      default: ''
	    }
	  },
	  userId: { type: ObjectId, ref: 'User' },
	  transactionId: { type: ObjectId, ref: 'Transaction' },
	  status: {
	    type: String,
	    enum: ['pending', 'uploaded'],
	    default: 'pending'
	  },
	  uploadForm: { type: String },
	  shippingAddress: {
	    awbId: { type: String },
	    referenceId: { type: String },
	    boxid: { type: String, required: true },
	    shipdate: { type: String, required: true },
	    customerName: { type: String, required: true },
	    postal: { type: String, required: true },
	    jpaddress1: { type: String, required: true },
	    jpaddress2: { type: String, required: true },
	    phoneNumber: { type: String, required: true },
	    kbn: { type: String, required: true },
	    wgt: { type: Number, required: true },
	    grandTotal: { type: Number, required: true },
	    deliveryDate: { type: String, required: true },
	    deliveryTime: { type: Number, required: true },
	    souryo: { type: Number, default: 0 },
	    tesuryo: { type: Number, default: 0 },
	    ttlAmount: { type: Number, required: true },
	    codFlg: { type: Number, default: 0 }
	  },
	  items: [{
	    productId: { type: ObjectId, ref: 'Product', required: true },
	    itemcd: { type: String, required: true },
	    itemname: { type: String, required: true },
	    usage: { type: Number, default: 0 },
	    origin: { type: String, required: true },
	    piece: { type: Number, required: true },
	    unitprice: { type: Number, required: true }
	  }]
	}, {
	  bufferCommands: true
	});
	exports.default = sagawaSchema;

/***/ }),
/* 21 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _keys = __webpack_require__(5);

	var _keys2 = _interopRequireDefault(_keys);

	var _assign = __webpack_require__(10);

	var _assign2 = _interopRequireDefault(_assign);

	var _promise = __webpack_require__(6);

	var _promise2 = _interopRequireDefault(_promise);

	var _bluebird = __webpack_require__(3);

	var _Transaction = __webpack_require__(22);

	var _Transaction2 = _interopRequireDefault(_Transaction);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	/* eslint-disable no-use-before-define, no-console, import/newline-after-import */
	exports.default = function (db) {
	  /**
	  * 1) Remove all documents instances.
	  *
	  * @param {string} collectionName - name of collection - only used to Verify operation accuracy with console.logs.
	  *
	  * @return {object} - Promise: resolved - Transaction details.
	  */
	  _Transaction2.default.statics.dropCollection = function (collectionName) {
	    return new _promise2.default(function (resolve, reject) {
	      console.log('\n\n@Transaction.dropCollection');

	      return _bluebird.Promise.fromCallback(function (cb) {
	        return Transaction.remove({}, cb);
	      }).then(function (result) {
	        console.log('\nSuccessfully removed all Documents on the ', collectionName, ' collection.\nResult: ', result);
	        resolve(result);
	      }).catch(function (error) {
	        console.log('\nERROR trying to drop collection ', collectionName);
	        reject(error);
	      });
	    });
	  };

	  _Transaction2.default.statics.removeOne = function (_ref) {
	    var id = _ref.id;
	    return new _promise2.default(function (resolve, reject) {
	      console.log('\n\n@Transaction.removeOne');

	      if (!id) return reject('Missing required arguments. "id": ' + (id || 'undefined'));

	      Transaction.findByIdAndRemove(id).exec().then(function (deletedDoc) {
	        console.log('\nSuccessfully removed _id: ', deletedDoc._id);
	        resolve(deletedDoc);
	      }).catch(function (error) {
	        console.log('Error trying to remove document with _id "' + id + '"');
	        reject('Error trying to remove document with _id "' + id + '"');
	      });
	    });
	  };

	  _Transaction2.default.statics.updateDoc = function (eventBody) {
	    return new _promise2.default(function (resolve, reject) {
	      console.log('\n\n@Transaction.updateDoc');

	      if (!eventBody) return reject('Missing required arguments. "eventBody": ' + (eventBody || 'undefined'));

	      delete eventBody.collectionName;
	      delete eventBody.databaseName;
	      delete eventBody.operationName;

	      var updateArgs = (0, _assign2.default)({}, eventBody);
	      (0, _keys2.default)(updateArgs).forEach(function (key) {
	        if (/\[\]/gi.test(updateArgs[key])) {
	          try {
	            updateArgs[key] = JSON.parse(updateArgs[key]);
	          } catch (error) {
	            reject('ERROR while trying to parse input string array into array literal.  ERROR = ' + error + '.');
	            return null;
	          }
	        }
	      });

	      Transaction.findByIdAndUpdate({ _id: eventBody.id }, { $set: updateArgs }, { new: true }).exec().then(function (result) {
	        console.log('Successfully updated collection ' + eventBody.collectionName + '.  RESULT = ' + result);
	        return resolve(result);
	      }).catch(function (error) {
	        console.log('Error trying to update collection "' + eventBody.collectionName + '".  ERROR = ' + error);
	        return reject(error);
	      });
	    });
	  };

	  console.log('\n\nCreating Transaction collection...');
	  var Transaction = db.model('Transaction', _Transaction2.default);
	  return Transaction;
	};

/***/ }),
/* 22 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	var Schema = __webpack_require__(8).Schema;

	var ObjectId = Schema.Types.ObjectId;
	var transactionSchema = new Schema({
	  error: {
	    hard: {
	      type: Boolean,
	      default: false
	    },
	    soft: {
	      type: Boolean,
	      default: false
	    },
	    message: {
	      type: String,
	      default: ''
	    }
	  },
	  date: {
	    type: Date,
	    default: Date.now,
	    required: true
	  },
	  comments: { type: String },
	  termsAgreement: { type: Boolean },
	  user: { type: ObjectId, ref: 'User' },
	  products: [{
	    _id: { type: ObjectId, ref: 'Product', required: true },
	    qty: { type: Number, required: true }
	  }],
	  sagawa: { type: ObjectId, ref: 'Sagawa' },
	  emailAddress: { type: String, default: '' },
	  emailLanguage: {
	    type: String,
	    enum: ['english', 'japanese'],
	    default: 'english'
	  },
	  invoiceEmailNoTracking: { type: String, default: '' },
	  invoiceEmail: { type: String, default: '' },
	  jpyFxRate: { type: String, required: true },
	  taxes: {
	    cityRate: { type: String, required: true },
	    stateRate: { type: String, required: true },
	    totalRate: { type: String, required: true }
	  },
	  total: {
	    subTotal: { type: String, required: true },
	    taxes: { type: String, required: true },
	    grandTotal: { type: String, required: true },
	    discount: {
	      qty: { type: Boolean, default: false },
	      qtyAmount: { type: String, default: '' },
	      register: { type: Boolean, default: false },
	      registerAmount: { type: String, default: '' }
	    }
	  },
	  square: {
	    locationId: { type: String, default: '' },
	    transactionId: { type: String, default: '' },
	    billingCountry: { type: String, required: true },
	    shippingAddress: {
	      shippingPrefecture: { type: String, required: true },
	      shippingCity: { type: String, required: true }
	    },
	    cardInfo: {
	      last4: { type: String, required: true },
	      nameOnCard: { type: String, required: true },
	      cardNonce: { type: String, default: '', required: true },
	      postalCode: { type: String, default: '' }
	    },
	    charge: {
	      amount: { type: String, required: true },
	      currency: { type: String, required: true }
	    }
	  }
	});
	exports.default = transactionSchema;

/***/ }),
/* 23 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	var _keys = __webpack_require__(5);

	var _keys2 = _interopRequireDefault(_keys);

	var _assign = __webpack_require__(10);

	var _assign2 = _interopRequireDefault(_assign);

	var _extends2 = __webpack_require__(1);

	var _extends3 = _interopRequireDefault(_extends2);

	var _promise = __webpack_require__(6);

	var _promise2 = _interopRequireDefault(_promise);

	var _bluebird = __webpack_require__(3);

	var _User = __webpack_require__(24);

	var _User2 = _interopRequireDefault(_User);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	/* eslint-disable no-use-before-define, no-console, import/newline-after-import */
	exports.default = function (db) {
	  /**
	  * 1) Remove all documents instances.
	  *
	  * @param {string} collectionName - name of collection - only used to Verify operation accuracy with console.logs.
	  *
	  * @return {object} - Promise: resolved - User details.
	  */
	  _User2.default.statics.dropCollection = function (collectionName) {
	    return new _promise2.default(function (resolve, reject) {
	      console.log('\n\n@User.dropCollection');

	      return _bluebird.Promise.fromCallback(function (cb) {
	        return User.remove({}, cb);
	      }).then(function (result) {
	        console.log('\nSuccessfully removed all Documents on the ', collectionName, ' collection.\nResult: ', result);
	        resolve(result);
	      }).catch(function (error) {
	        console.log('\nERROR trying to drop collection ', collectionName);
	        reject(error);
	      });
	    });
	  };
	  /**
	  * 1) Validate required fields exist.
	  * 2) Create a new User.
	  *
	  * @param {object} fields - Required fields for creating new User.
	  *
	  * @return {object} - Promise: resolved - User details.
	  */
	  _User2.default.statics.createDoc = function (fields) {
	    return new _promise2.default(function (resolve, reject) {
	      console.log('\n\n@User.createUser');

	      if (!fields) return reject('Missing required arguments. "fields": ' + (fields || 'undefined'));

	      var type = fields.type,
	          purpose = fields.purpose,
	          language = fields.language,
	          subjectData = fields.subjectData,
	          bodyHtmlData = fields.bodyHtmlData,
	          bodyTextData = fields.bodyTextData,
	          replyToAddress = fields.replyToAddress;


	      if (!type || !purpose || !language || !replyToAddress || !subjectData || !bodyHtmlData || !bodyTextData) {
	        reject((0, _extends3.default)({ error: 'Missing required fields to create a new User.' }, fields));
	      } else {
	        _bluebird.Promise.fromCallback(function (cb) {
	          return User.create((0, _extends3.default)({}, fields), cb);
	        }).then(function (newUser) {
	          console.log('\nSuccessfully created new User!\n _id: ', newUser._id);
	          resolve(newUser);
	        });
	      }
	    });
	  };

	  _User2.default.statics.removeOne = function (_ref) {
	    var id = _ref.id;
	    return new _promise2.default(function (resolve, reject) {
	      console.log('\n\n@User.removeOne');

	      if (!id) return reject('Missing required arguments. "id": ' + (id || 'undefined'));

	      User.findByIdAndRemove(id).exec().then(function (deletedDoc) {
	        console.log('\nSuccessfully removed _id: ', deletedDoc._id);
	        resolve(deletedDoc);
	      }).catch(function (error) {
	        console.log('Error trying to remove document with _id "' + id + '"');
	        reject('Error trying to remove document with _id "' + id + '"');
	      });
	    });
	  };

	  _User2.default.statics.updateDoc = function (eventBody) {
	    return new _promise2.default(function (resolve, reject) {
	      console.log('\n\n@User.updateDoc');

	      if (!eventBody) return reject('Missing required arguments. "eventBody": ' + (eventBody || 'undefined'));

	      delete eventBody.collectionName;
	      delete eventBody.databaseName;
	      delete eventBody.operationName;

	      var updateArgs = (0, _assign2.default)({}, eventBody);
	      (0, _keys2.default)(updateArgs).forEach(function (key) {
	        if (/\[\]/gi.test(updateArgs[key])) {
	          try {
	            updateArgs[key] = JSON.parse(updateArgs[key]);
	          } catch (error) {
	            reject('ERROR while trying to parse input string array into array literal.  ERROR = ' + error + '.');
	            return null;
	          }
	        }
	      });

	      User.findByIdAndUpdate({ _id: eventBody.id }, { $set: updateArgs }, { new: true }).exec().then(function (result) {
	        console.log('Successfully updated collection ' + eventBody.collectionName + '.  RESULT = ' + result);
	        return resolve(result);
	      }).catch(function (error) {
	        console.log('Error trying to update collection "' + eventBody.collectionName + '".  ERROR = ' + error);
	        return reject(error);
	      });
	    });
	  };

	  console.log('\n\nCreating User collection...');
	  var User = db.model('User', _User2.default);
	  return User;
	};

/***/ }),
/* 24 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	var Schema = __webpack_require__(8).Schema;

	var ObjectId = exports.ObjectId = Schema.Types.ObjectId;
	var userSchema = new Schema({
	  name: {
	    first: { type: String },
	    last: { type: String },
	    display: { type: String }
	  },
	  pictures: {
	    small: { type: String },
	    large: { type: String },
	    default: {
	      type: String,
	      default: 'https://s3-ap-northeast-1.amazonaws.com/nj2jp-react/default-user.png'
	    }
	  },
	  authentication: {
	    signedUp: { type: Date },
	    password: { type: String },
	    createdAt: { type: Date },
	    totalLogins: { type: Number },
	    lastLogin: [{
	      date: { type: Date, default: new Date() },
	      device: { type: String, default: 'computer' }
	    }],
	    ageVerified: { type: Boolean, default: false },
	    auth0Identities: [{
	      provider: { type: String },
	      user_id: { type: String },
	      connection: { type: String },
	      isSocial: { type: Boolean }
	    }]
	  },
	  contactInfo: {
	    email: { type: String },
	    phone: { type: String },
	    locale: { type: String },
	    timezone: { type: Number },
	    location: {
	      ipAddress: { type: String },
	      lat: { type: String },
	      long: { type: String },
	      country: { type: String }
	    },
	    devices: [{
	      hardware: { type: String },
	      os: { type: String }
	    }],
	    socialNetworks: [{
	      name: { type: String },
	      link: { type: String }
	    }]
	  },
	  shopping: {
	    cart: [{
	      qty: { type: Number },
	      nicotineStrength: { type: Number },
	      product: { type: ObjectId, ref: 'Product' }
	    }],
	    transactions: [{ type: ObjectId, ref: 'Transaction' }]
	  },
	  permissions: {
	    role: {
	      type: String,
	      enum: ['user', 'admin', 'devAdmin', 'wholeseller', 'distributor'],
	      required: true
	    }
	  },
	  userStory: {
	    age: { type: Number },
	    birthday: { type: Date },
	    bio: { type: String },
	    gender: { type: String }
	  },
	  marketHero: {
	    tags: [{
	      name: { type: String },
	      date: { type: Date }
	    }]
	  },
	  socialProfileBlob: {
	    line: { type: String },
	    facebook: { type: String },
	    google: { type: String },
	    twitter: { type: String },
	    linkedin: { type: String }
	  }
	}, { bufferCommands: true });
	exports.default = userSchema;

/***/ }),
/* 25 */
/***/ (function(module, exports) {

	module.exports = require("dotenv");

/***/ }),
/* 26 */
/***/ (function(module, exports) {

	module.exports = require("babel-polyfill");

/***/ })
/******/ ])));